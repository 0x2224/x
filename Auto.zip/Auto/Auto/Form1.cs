﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            Hide();
            Visible = false;
            InitializeComponent();
            notifyIcon1.Visible = true;
            this.WindowState = FormWindowState.Minimized;
            loop();
        }
        private async void loop()
        {
            for (int i = 0; i < 4; i++)
            {
                await Task.Delay(1000);
            }
            string com = "shutdown /r /t 0";
            System.Diagnostics.Process.Start("cmd.exe", "/k "+com);

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }
    }
}
